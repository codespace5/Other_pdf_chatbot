import React, { useState } from 'react';
import ChatbotWidget from './ChatbotWidget';
import MyComponent from './components/MyComponent';
import "./App.scss"

const App = () => {
  return (
    <>
      <div className='chatbotWidget'>
        <ChatbotWidget />
      </div>
      {/* <MyComponent /> */}
    </>
  );
}

export default App;